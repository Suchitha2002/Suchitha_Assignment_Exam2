﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2Exam
{
    internal class p2
    {
        public class Book
        {
            public int BookId { get; set; }
            public string BookName { get; set; }
            public double Price { get; set; }
            public string Author { get; set; }
            public string Publisher { get; set; }
        }

        public interface IBookRepository
        {
            void CreateBook(Book book);
            void UpdateBook(int bookId, Book updatedBook);
            Book GetBookById(int bookId);
            List<Book> GetBooksByName(string bookName);
            List<Book> GetBooksByAuthor(string author);
            List<Book> GetBooksByAuthorAndPublisher(string author, string publisher);
            List<Book> GetAllBooks();



        }


        public class BookRepository : IBookRepository
        {
            private List<Book> books = new List<Book>();

            public void CreateBook(Book book)
            {
                books.Add(book);
            }

            public void UpdateBook(int bookId, Book updatedBook)
            {
                var book = books.FirstOrDefault(b => b.BookId == bookId);
                if (book != null)
                {
                    book.BookName = updatedBook.BookName ?? book.BookName;

                    book.Price = updatedBook.Price != 0 ? updatedBook.Price : book.Price;

                    book.Author = updatedBook.Author ?? book.Author;

                    book.Publisher = updatedBook.Publisher ?? book.Publisher;

                }
                else
                {
                    throw new Exception("Book is not found");
                }
            
            }
            public Book GetBookById(int bookId)
            {
                return books.FirstOrDefault(b => b.BookId == bookId);
            }

            public List<Book> GetBooksByName(string bookName)
            {
                return books.Where(b => b.BookName.Equals(bookName, StringComparison.OrdinalIgnoreCase)).ToList();
            }

            public List<Book> GetBooksByAuthorr(string author)
            {
                return books.Where(b => b.Author.Equals(author, StringComparison.OrdinalIgnoreCase)).ToList();

            }

            public List<Book> GetBooksByAuthorAndPublisher(string author, string publisher)
            {
                return books.Where(b => b.Author.Equals(author, StringComparison.OrdinalIgnoreCase) &&
                 b.Publisher.Equals(publisher, StringComparison.OrdinalIgnoreCase)).ToList();

            }
            public List<Book> GetAllBooks()
            {
                return books;
            }

            List<Book> IBookRepository.GetBooksByAuthor(string author)
            {
                throw new NotImplementedException();
            }
        }

        class program
        {
            static void Main(string[] args)
            {
                BookRepository bookRepository = new BookRepository();
                while (true)
                {
                    Console.WriteLine("Library Management System");
                    Console.WriteLine("1.Create Book");
                    Console.WriteLine("2.Update Book details");
                    Console.WriteLine("3.Display Book details");
                    Console.WriteLine("4.Exit");
                    int choice = int.Parse(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            CreateBook(bookRepository);
                            break;
                        case 2:
                            UpdateBook(bookRepository);
                            break;
                        case 3:
                            DisplayBookDetails(bookRepository);
                            break;
                        case 4:
                            return;

                        default:
                            Console.WriteLine("Invalid choice. Please try again.");
                            break;

                    }

                }

            }

            static void CreateBook(IBookRepository bookRepository)
            {
                Book book = new Book();
                Console.WriteLine("Enter Book ID: ");
                book.BookId = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter Book Name: ");
                book.BookName = Console.ReadLine();
                Console.WriteLine("Enter Price: ");
                book.Price = double.Parse(Console.ReadLine());
                Console.WriteLine("Enter Author: ");
                book.Author = Console.ReadLine();
                Console.WriteLine("Enter Publisher: ");
                book.Publisher = Console.ReadLine();

                bookRepository.CreateBook(book);
                Console.WriteLine("Book created successfully.");
            
            }

            static void UpdateBook(IBookRepository bookRepository)
            {
                Console.WriteLine("Enter Book ID to update: ");
                int bookId = int.Parse(Console.ReadLine());
                Book updatedBook = new Book();
                Console.WriteLine("Enter new Book Name (leave blank to keep current): ");

                updatedBook.BookName = Console.ReadLine();
                Console.WriteLine("Enter new Price (enter 0 to keep current): ");

                updatedBook.Price = double.Parse(Console.ReadLine());
                Console.WriteLine("Enter new Author (leave blank to keep current): ");

                updatedBook.Author = Console.ReadLine();
                Console.WriteLine("Enter new Publisher (leave blank to keep current): ");

                updatedBook.Publisher = Console.ReadLine();
                try
                {
                    bookRepository.UpdateBook(bookId, updatedBook);
                    Console.WriteLine("Book updated successfully.");

                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }
            static void DisplayBookDetails(IBookRepository bookRepository)
            {
                Console.WriteLine("1. Display book details based on bookId");
                Console.WriteLine("2. Display book details based on bookName");
                Console.WriteLine("3. Display all books based on author");
                Console.WriteLine("4. Display all books based on author and publisher");
                Console.WriteLine("5.Display all books details");
                Console.WriteLine("Enter your choice");

                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Enter Book ID: ");
                        int bookId = int.Parse(Console.ReadLine());
                        var bookById = bookRepository.GetBookById(bookId);
                        if (bookById != null)
                        {
                            DisplayBook(bookById);
                        }
                        else
                        {
                            Console.WriteLine("Book not found.");
                        }
                        break;

                    case 2:
                        Console.WriteLine("Enter Book Name: ");
                        string bookName = Console.ReadLine();
                        var booksByName = bookRepository.GetBooksByName(bookName);
                        if (booksByName.Any())
                        {
                            foreach (var book in booksByName)
                            {
                                DisplayBook(book);
                            }
                        }
                        else
                        {
                            Console.WriteLine("No books found with the given name.");
                        }
                        break;

                    case 3:
                        Console.WriteLine("Enter Author: ");
                        string author = Console.ReadLine();
                        var booksByAuthor = bookRepository.GetBooksByAuthor(author);
                        if (booksByAuthor.Any())
                        {
                            foreach (var book in booksByAuthor)
                            {
                                DisplayBook(book);
                            }

                        }
                        else
                        {
                            Console.WriteLine("No books found by the author.");

                        }break;
                    
                    case 4:

                        Console.WriteLine("Enter Author: ");
                        author = Console.ReadLine();
                        Console.Write("Enter Publisher: ");
                        string publisher = Console.ReadLine();
                        var booksByAuthorAndPublisher = bookRepository.GetBooksByAuthorAndPublisher(author, publisher);
                        if (booksByAuthorAndPublisher.Any())
                        {
                            foreach (var book in booksByAuthorAndPublisher)
                            {

                                DisplayBook(book);

                            }

                        }
                        else
                        {
                            Console.WriteLine("No books found by the given author and publisher.");


                        }break;

                    case 5:

                        var allBooks = bookRepository.GetAllBooks();
                        if (allBooks.Any())
                        {
                            foreach (var book in allBooks)
                            {
                                DisplayBook(book);
                            }

                        }
                        else
                        {
                            Console.WriteLine("No books available.");

                        }break;

                    default:
                        Console.WriteLine("Invalid choice. Please try again.");

                        break;
                }
                static void DisplayBook(Book book)
                {
                    Console.WriteLine($"Book ID: {book.BookId}");
                    Console.WriteLine($"Book Name: {book.BookName}");
                    Console.WriteLine($"Price: {book.Price}");
                    Console.WriteLine($"Author: {book.Author}");
                    Console.WriteLine($"Publisher: {book.Publisher}");
                    Console.WriteLine();
                }






            }




        }






    }

}
